package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Curso;
import com.example.demo.repository.CursoRepository;


//para que sea utilizada en el controlador
@Service
public class CursoService {
    @Autowired
    private CursoRepository cursoRepository;
    
    public String almacenarCurso(Curso curso){
        cursoRepository.save(curso);
        return "Curso almacenado !!! ok";
    }
}
